<?php include 'inc/header.php';?>
		
<div class="contentsection contemplate clear">
	
	<div class = "maincontent clear">
	<div class="items">
	<img src="images/abrar.jpg" alt="MyImage"/>
		<div class="shadow">
		<div class="stext">
		<h2>Abrar Haque, WEB Developer</h2>
		<p>Intermediate in JavaFX & PHP</p>
		</div>
		</div>
	</div>
	</div>
	
	<?php include 'inc/sidebar.php';?>

	<?php include 'inc/footer.php';?>