<?php include 'inc/header.php';?>
		
<div class="contentsection contemplate clear">
	
	<div class = "maincontent clear">
	<div class="about">
	<h2>Contact Me</h2>
	
	<!-- <p>Your First Name: <input type="text" name="firstname" placeholder="Your First Name"></p>
	<p>Your Last Name: <input type="text" name="lastname" placeholder="Your Last Name"></p>
	<p>Your Email: <input type="email" name="email" placeholder="Your Email"></p>
	<p>Your Address:<input type="text" name="address" placeholder="Your address"></p>
	<p><input type="submit" name="submit" value="Submit"></p> -->
	
	<table>
		<tr>
			<td>
			Your First Name: 
			</td>
			<td>
			<input type="text" name="firstname" placeholder="Your First Name">
			</td>
		</tr>
		<tr>
			<td>
			Your Last Name: 
			</td>
			<td>
			<input type="text" name="lastname" placeholder="Your Last Name">
			</td>
		</tr>
		<tr>
			<td>
			Your Email: 
			</td>
			<td>
			<input type="email" name="email" placeholder="Your Email">
			</td>
		</tr>
		<tr>
			<td>
			Your Address: 
			</td>
			<td>
			<input type="text" name="address" placeholder="Your Address">
			</td>
		</tr>
		<tr>
			<td>
			Your Message: 
			</td>
			<td>
			<textarea></textarea>
			</td>
		</tr>
		
		<tr>
			<td>
			</td>
			<td>
			<input type="submit" name="submit" value="Submit">
			</td>
		</tr>
	</table>
	</div>
	
	<div class="gmap">
	<div id="map"></div>
	</div>
	
	</div>
	<div class = "sidebar clear">
		<div class="samesidebar clear">
		<h2>Latest Article</h2>
		 <ul>
			<li><a href="#">Post title one</li></a>
			<li><a href="#">Post title two</li></a>
			<li><a href="#">Post title three</li></a>
			<li><a href="#">Post title four</li></a>
			<li><a href="#">Post title five</li></a>
		 </ul>
		</div>
		
		<div class="samesidebar clear">
		<h2>Popular Articles</h2>
			<div class="popular clear">
				<h3><a href="#">Popular Post Title</a></h3>
				<img src="images/Mouse-PIC.jpg" alt="Popular Post"/>
				<p>Some Popular text will go here.Some Popular text will go here.Some Popular text will go here.Some Popular text will go here.Some Popular text will go here.</p>
			</div>
			<div class="popular clear">
				<h3><a href="#">Popular Post Title</a></h3>
				<img src="images/Mouse-PIC.jpg" alt="Popular Post"/>
				<p>Some Popular text will go here.Some Popular text will go here.Some Popular text will go here.Some Popular text will go here.Some Popular text will go here.</p>
			</div>
		</div>

		<div class="samesidebar clear">
		<h2>Sidebar 3 Title</h2>
		<p>Some SIDEBAR text will go here.Some SIDEBAR text will go here.Some SIDEBAR text will go here.Some SIDEBAR text will go here.Some SIDEBAR text will go here.Some SIDEBAR text will go here.Some SIDEBAR text will go here.Some SIDEBAR text will go here.</p>
		</div>		
	</div>

</div>
<!--<div style="clear:both"></div>-->
<?php include 'inc/footer.php';?>