<?php include 'inc/header.php';?>

<div class="contentsection contemplate clear">
	
	<div class = "maincontent clear">
	<div class="about">
	<h2>About Me</h2>
	<img src="images/red.png" alt="MyImage"/>
	<p>ABOUT ME...Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will.</p>
	<p>Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.</p>
	<p>Some content will go here.Some content will go here.Some content will.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.</p>
	</div>
	</div>

	<?php include 'inc/sidebar.php';?>

</div>
<?php include 'inc/footer.php';?>