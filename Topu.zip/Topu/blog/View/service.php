<?php include 'inc/header.php';?>
		
<div class="contentsection contemplate clear">
	
	<div class = "maincontent clear">
	<div class="about">
	<h2>Our Services</h2>
	<img src="images/red.png" alt="MyImage"/>
	<p>ABOUT ME...Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will.</p>
	<p>Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.</p>
	<p>Some content will go here.Some content will go here.Some content will.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.Some content will go here.</p>
	</div>
	</div>
	<div class = "sidebar clear">
		<div class="samesidebar clear">
		<h2>Latest Article</h2>
		 <ul>
			<li><a href="#">Post title one</li></a>
			<li><a href="#">Post title two</li></a>
			<li><a href="#">Post title three</li></a>
			<li><a href="#">Post title four</li></a>
			<li><a href="#">Post title five</li></a>
		 </ul>
		</div>
		
		<?php include 'inc/sidebar.php';?>

</div>

<?php include 'inc/footer.php';?>