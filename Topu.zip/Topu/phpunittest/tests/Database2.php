<?php
Class Database2{
 

 //Add
public function add($a, $b){
  return $a+$b;
}
//TrueFalse
public function testTrueAssertsToTrue(){
  $this->assertTrue(FALSE);
}
 
}